import smtplib

from django.core.files.storage import FileSystemStorage
from django.shortcuts import render, redirect
from django.urls import reverse

# Create your views here.
import datetime
import os
from django.core.files.storage import FileSystemStorage
from .models import UserLogin, worker_details, former_details, crop_date, rental_details, \
    equipment_details, farmerrequest, payment
from instutionhead.settings import BASE_DIR
from django.db.models import Q


def index(request):
    return render(request, 'index.html')


def logcheck(request):
    if request.method == "POST":
        username = request.POST.get('t1', '')
        password = request.POST.get('t2', '')
        request.session['username'] = username
        # if username=="admin" and password=="admin":
        checklogin = UserLogin.objects.filter(username=username).values()
        for a in checklogin:
            utype = a['utype']
            upass = a['password']
            if (upass == password):
                if (utype == "farmer"):
                    return render(request, 'farmer_home.html', {'msg': 'welcome to farmer'})
                if (utype == "shop"):
                    return render(request, 'shop_home.html', {'msg': 'welcome to Manager'})

            else:
                return render(request, 'login.html', {'msg': 'Invalid Email-id or password'})

    return render(request, 'login.html')


def achangepassword(request):
    uname = request.session['username']
    if request.method == 'POST':
        currentpass = request.POST.get('t1', '')
        newpass = request.POST.get('t2', '')
        confirmpass = request.POST.get('t3', '')

        ucheck = UserLogin.objects.filter(username=uname).values()
        for a in ucheck:
            u = a['username']
            p = a['password']
            if u == uname and currentpass == p:
                if newpass == confirmpass:
                    UserLogin.objects.filter(username=uname).update(password=newpass)
                    base_url = reverse('logcheck')
                    msg = 'password has been changed successfully'
                    return redirect(base_url, msg=msg)
                else:
                    return render(request, 'changepassword.html',
                                  {'msg': 'both the usename and password are incorrect'})
            else:
                return render(request, 'changepassword.html', {'msg': 'invalid username'})
    return render(request, 'changepassword.html')


def insertworkers(request):
    uname = request.session['username']
    if request.method == "POST":
        s1 = request.POST.get('t1', '')
        s2 = request.POST.get('t2', '')
        s3 = request.POST.get('t3', '')
        s4 = request.POST.get('t4', '')
        s5 = request.POST.get('t5', '')
        s6 = request.POST.get('t6', '')

        worker_details.objects.create(worker_id=s1, name=s2, address=s3, wages=s4, work_type=s5, mobile_no=s6)

        return render(request, 'worker_details.html')
    eid = worker_details.objects.all().order_by('id').last()

    enum = int(eid.worker_id) + 1
    return render(request, "worker_details.html", {'uname': uname, 'enum': enum})


def insertEquipmentDetails(request):
    uname = request.session['username']
    if request.method == "POST" and request.FILES['myfile']:
        s1 = request.POST.get('t1', '')
        s2 = request.POST.get('t2', '')
        s3 = request.POST.get('t3', '')
        s4 = request.POST.get('t4', '')
        s5 = request.POST.get('t5', '')
        myfile = request.FILES['myfile']
        s7 = request.POST.get('t7', '')
        s8 = request.POST.get('t8', '')
        s9 = request.POST.get('t9', '')

        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        uploaded_file_url = fs.url(filename)
        pat = os.path.join(BASE_DIR, '/media/' + filename)

        equipment_details.objects.create(equipment_id=s1, name=s2, comapny=s3, equipment_type=s4, details=s5,
                                         photo=myfile,
                                         rent_per_day=s7, status=s8, usage=s9)

        return render(request, 'equipment_details.html')
    eid = equipment_details.objects.all().order_by('id').last()
    if eid == None:
        enum = 1
    else:

        enum = int(eid.equipment_id) + 1

    return render(request, "equipment_details.html", {'enum': enum})


def insertFarmerDetails(request):
    uname = request.session['username']

    if request.method == "POST":
        s1 = request.POST.get('t1', '')
        s2 = request.POST.get('t2', '')
        s3 = request.POST.get('t3', '')
        s4 = request.POST.get('t4', '')
        s5 = request.POST.get('t5', '')
        s6 = request.POST.get('t6', '')
        s7 = request.POST.get('t7', '')
        s8 = request.POST.get('t8', '')
        s9 = request.POST.get('t9', '')

        umail = former_details.objects.filter(emailid=s3).count()

        if umail:
            eid2 = former_details.objects.all().order_by('id').last()
            enum2 = int(eid2.former_id) + 1
            return render(request, "former_details.html", {'enum': enum2, 'msg': 'This email-id is already registered'})

        else:
            former_details.objects.create(former_id=s1, name=s2, emailid=s3, village=s4, address=s5, mobile_no=s6,
                                          password=s9, adhaar_no=s7, utar_no=s8)
            UserLogin.objects.create(username=s3, password=s9, utype='farmer')
            base_url = reverse('logcheck')

            return redirect(base_url)

    eid = former_details.objects.all().order_by('id').last()
    if eid == None:
        enum = 1
    else:
        enum = int(eid.former_id) + 1

    return render(request, "former_details.html", {'enum': enum})


def insertcrop(request):
    uname = request.session['username']
    if request.method == "POST" and request.FILES['myfile']:
        s1 = request.POST.get('t1', '')
        s2 = request.POST.get('t2', '')
        myfile = request.FILES['myfile']
        s4 = request.POST.get('t4', '')
        s5 = request.POST.get('t5', '')
        s6 = request.POST.get('t6', '')

        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        uploaded_file_url = fs.url(filename)
        pat = os.path.join(BASE_DIR, '/media/' + filename)

        crop_date.objects.create(crop_id=s1, name=s2, photo=myfile, date=s4, price=s5, quantity=s6)

        return render(request, 'crop_date.html', {'msg': 'Crop details added successfully'})
    eid = crop_date.objects.all().order_by('id').last()
    if eid == None:
        enum = 1
    else:
        enum = int(eid.crop_id) + 1

    return render(request, "crop_date.html", {'enum': enum})


def insertRequest(request):
    uname = request.session['username']
    print(uname)

    if request.method == "POST":
        s1 = request.POST.get('t1', '')
        s2 = request.POST.get('t2', '')
        s3 = request.POST.get('t3', '')
        s4 = request.POST.get('t4', '')
        s5 = request.POST.get('t5', '')
        s6 = request.POST.get('t6', '')

        farmerrequest.objects.create(farmer_id=s2, request_id=s1, equipment_id=s3, from_date=s4, till_date=s5,
                                     status='Pending')
        return render(request, 'userrequest.html', {'msg': 'Your request sent successfully'})
    eid = farmerrequest.objects.all().order_by('id').last()

    enum = int(eid.request_id) + 1
    fcheck = former_details.objects.filter(emailid=uname).values()
    for f in fcheck:
        fid = f['former_id']
    return render(request, "userrequest.html", {'enum': enum, 'fid': fid})


def insertRentalDetails(request):
    if request.method == "POST":
        s1 = request.POST.get('t1', '')
        s2 = request.POST.get('t2', '')
        s3 = request.POST.get('t3', '')
        s4 = request.POST.get('t4', '')
        s5 = request.POST.get('t5', '')
        s6 = request.POST.get('t6', '')
        s7 = request.POST.get('t7', '')
        s8 = request.POST.get('t8', '')
        s9 = request.POST.get('t9', '')

        rental_details.objects.create(request_id=s1, former_id=s2, equipment_id=s3, issue_date=s4, time=s5, advance=s6,
                                       total=s7, balance=s8, status='Pending')

        farmerrequest.objects.filter(request_id=s1, farmer_id=s2, equipment_id=s3).update(status='Issued',issue_date=s4, time=s5, advance=s6,
                                       total=s7, balance=s8)

        return render(request, 'rental_details.html', {'msg': 'Issued successfully'})

    return render(request, "rental_details.html", )


def insertpayment(request):
    uname = request.session['username']
    print(uname)
    fcheck = former_details.objects.filter(emailid=uname).values()
    for f in fcheck:
        fid = f['former_id']

    if request.method == "POST":
        s1 = request.POST.get('t1', '')
        s2 = request.POST.get('t2', '')
        s3 = request.POST.get('t3', '')
        s4 = request.POST.get('t4', '')
        s5 = request.POST.get('t5', '')
        s6 = request.POST.get('t6', '')

        paid=payment.objects.filter(request_id=s1, farmer_id=s2 , equipment_id=s6).count()
        if paid:
            return render(request, "paymentdetails.html",{'msg':'Advance already paid'})
        else:
            payment.objects.create(request_id=s1, farmer_id=s2, equipment_id=s6, total=s3, amtpaid=s4, balance=s5,
                                   status='PAID')

            rental_details.objects.filter(request_id=s1, former_id=s2, equipment_id=s6).update(status='PAID')



            return render(request, 'qrpage.html')

            # base_url = reverse('pay')
            #
            # return redirect(base_url)




    return render(request, "paymentdetails.html", {'fid': fid})


def insertWorkersDetails(request):
    uname = request.session['username']
    if request.method == "POST":
        s1 = request.POST.get('t1', '')
        s2 = request.POST.get('t2', '')
        s3 = request.POST.get('t3', '')
        s4 = request.POST.get('t4', '')
        s5 = request.POST.get('t5', '')
        s6 = request.POST.get('t6', '')

        worker_details.objects.create(worker_id=s1, name=s2, adress=s3, wages=s4, work_type=s5, mobile_no=s6)
        return render(request, ' worker_details.html')
    eid = worker_details.objects.all().order_by('id').last()
    if eid == None:
        enum = 1
    else:
        enum = int(eid.worker_id) + 1

    return render(request, " worker_details.html", {'enum': enum})


def cropdetailsview(request):
    userdict = crop_date.objects.all()
    return render(request, 'viewcropdetails.html', {'userdict': userdict})


def equdetailsview(request):
    userdict = equipment_details.objects.all()
    return render(request, 'viewequdaetails.html', {'userdict': userdict})


def showpayment(request):
    userdict = payment.objects.all()
    return render(request, 'viewpayment.html', {'userdict': userdict})


def farmerdetailsview(request):
    userdict = former_details.objects.all()
    return render(request, 'viewfarmerdetails.html', {'userdict': userdict})


def rentalview(request):
    uname = request.session['username']


    fcheck = former_details.objects.filter(emailid=uname).values()
    for f in fcheck:
        fid = f['former_id']

    userdict = rental_details.objects.filter(former_id=fid).all()



    return render(request, 'viewrental.html', {'userdict': userdict})


def reqview(request):
    userdict = farmerrequest.objects.all()
    return render(request, 'viewreq.html', {'userdict': userdict})


def workerdetailview(request):
    userdict = worker_details.objects.all()
    return render(request, 'viewworkerdetail.html', {'userdict': userdict})


def forgotpassword(request):
    if request.method == "POST":
        uname = request.POST.get('t1', '')
        user = UserLogin.objects.filter(username=uname).count()
        if user >= 1:
            userlog = UserLogin.objects.filter(username=uname).values()
            for u in userlog:
                upass = u['password']
                content = upass
                mail = smtplib.SMTP('smtp.gmail.com', 587)
                mail.ehlo()
                mail.starttls()
                mail.login('shamajoshi586@gmail.com', 'kcrnwudsmiyswvki')
                mail.sendmail('shamajoshi586@gmail.com', uname, content)
                mail.close()
                return render(request, 'login.html', {'msg': 'Your password has been sent to your E-mail'})
        else:
            return render(request, 'forgotpassword.html', {'msg': 'Enter a valid username'})
    return render(request, 'forgotpassword.html')


def aboutus(request):
    return render(request, 'aboutus.html')


def pay(request):
    return render(request, 'qrpage.html')
