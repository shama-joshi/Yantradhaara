from django.db import models

# Create your models here.
class UserLogin(models.Model):
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    utype = models.CharField(max_length=50)


class equipment_details(models.Model):
    equipment_id = models.CharField(max_length=20)
    name = models.CharField(max_length=60)
    comapny = models.CharField(max_length=60)
    equipment_type = models.CharField(max_length=80)
    details = models.CharField(max_length=100)
    photo = models.FileField(upload_to='documents/')
    rent_per_day = models.CharField(max_length=30)
    status = models.CharField(max_length=80)
    usage = models.CharField(max_length=100)


class former_details(models.Model):
    former_id = models.CharField(max_length=20)
    name = models.CharField(max_length=70)
    emailid=models.CharField(max_length=50)
    village = models.CharField(max_length=60)
    address = models.CharField(max_length=100)
    mobile_no = models.CharField(max_length=20)
    password = models.CharField(max_length=50)
    adhaar_no = models.CharField(max_length=20)
    utar_no = models.CharField(max_length=20)


class crop_date(models.Model):
    crop_id = models.CharField(max_length=20)
    name = models.CharField(max_length=50)
    photo = models.FileField(upload_to='documents/')
    date = models.CharField(max_length=20)
    price = models.CharField(max_length=20)
    quantity = models.CharField(max_length=20)
class farmerrequest(models.Model):
    farmer_id = models.CharField(max_length=20)
    request_id = models.CharField(max_length=50)
    equipment_id = models.CharField(max_length=20)
    from_date = models.CharField(max_length=20)
    till_date = models.CharField(max_length=20)
    status = models.CharField(max_length=60)
    issue_date = models.CharField(max_length=20)
    time = models.CharField(max_length=20)
    advance = models.CharField(max_length=20)
    total = models.CharField(max_length=20)
    balance = models.CharField(max_length=20)


class rental_details(models.Model):
    request_id = models.CharField(max_length=20)
    former_id = models.CharField(max_length=50)
    equipment_id = models.CharField(max_length=20)
    issue_date = models.CharField(max_length=20)
    time = models.CharField(max_length=20)
    advance = models.CharField(max_length=20)
    total = models.CharField(max_length=20)
    balance = models.CharField(max_length=20)
    status = models.CharField(max_length=60)



class payment(models.Model):
    request_id = models.CharField(max_length=20)
    farmer_id= models.CharField(max_length=20)
    equipment_id = models.CharField(max_length=20)
    total = models.CharField(max_length=50)
    amtpaid = models.CharField(max_length=100)
    balance = models.CharField(max_length=20)
    status = models.CharField(max_length=50)


class worker_details(models.Model):
    worker_id = models.CharField(max_length=20)
    name = models.CharField(max_length=50)
    address=models.CharField(max_length=100)
    wages = models.CharField(max_length=20)
    work_type = models.CharField(max_length=80)
    mobile_no = models.CharField(max_length=80)







